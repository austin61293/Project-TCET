# Name: Empirical Bayesian Kriging_Example_02.py
# Description: Bayesian kriging approach whereby many models created around the
#   semivariogram model estimated by the restricted maximum likelihood algorithm is used.
# Interpolate a series of point features onto a raster to create a prediction model map
# Data derived from Hanford Nuclear Site Clean Up initiative by DOE
# Author: Drew Garcia

# Import system modules
import os
import arcpy
from arcpy import env
from arcpy.sa import *

# Set environment settings

arcpy.env.workspace = "C:\ARCGIS Training\Tricities_EBK"
arcpy.env.scratchWorkspace = "C:\ARCGIS Training\Tricities_EBK"
arcpy.env.overwriteOutput = True

#set raster analysis to define which features will be processed in the arcmap
arcpy.env.cellSize = 5000
arcpy.env.mask = "C:\ARCGIS Training\Tricities_EBK\GwRep2010_Shapefiles\GwInterestAreas_2008.shp"

# Set the extent environment
arcpy.env.extent = "C:\ARCGIS Training\Tricities_EBK\GwRep2010_Shapefiles\GwInterestAreas_2008.shp"
arcpy.env.extent = arcpy.Extent(551174.687500, 597336.875000, 155409.328100, 102622.312500)
arcpy.env.extent = "551174.687500, 597336.875000, 155409.328100, 102622.312500"


# Set local variables
inPointFeatures = "C:\ARCGIS Training\Tricities_EBK\GwRep2010_Shapefiles\I129_CY2010_WellsCopy.shp"
zField = "VALUE"
outLayer = "outEBK"
outRaster = ""
cellSize = 10000.0
transformation = "EMPIRICAL"
maxLocalPoints = 100
overlapFactor = 1
numberSemivariograms = 100

# Set variables for search neighborhood
radius = 12764
standard = 1
searchNeighbourhood = arcpy.SearchNeighborhoodStandardCircular(radius, standard)
outputType = "PREDICTION"
quantileValue = ""
thresholdType = ""
probabilityThreshold = ""
semivariogram = "K_BESSEL"

# Check out the ArcGIS Geostatistical Analyst extension license
arcpy.CheckOutExtension("GeoStats")
arcpy.CheckOutExtension("Spatial")

# Execute EmpiricalBayesianKriging
arcpy.EmpiricalBayesianKriging_ga(inPointFeatures, zField, outLayer, outRaster, cellSize, transformation, maxLocalPoints, overlapFactor, numberSemivariograms, searchNeighbourhood, outputType, quantileValue, thresholdType, probabilityThreshold, semivariogram)

